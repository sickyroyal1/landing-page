import React, { useState, useMemo } from 'react';
import { TimeSlot, CourtLocation } from '../types';
import { Calendar as CalendarIcon, Clock, MapPin, ChevronLeft, ChevronRight, CheckCircle2, Lock, Filter, Sparkles, AlertCircle } from 'lucide-react';

interface AvailabilityCalendarProps {
  timeSlots: TimeSlot[];
  courts: CourtLocation[];
  onSelectSlot: (slot: TimeSlot) => void;
}

export const AvailabilityCalendar: React.FC<AvailabilityCalendarProps> = ({
  timeSlots,
  courts,
  onSelectSlot
}) => {
  // Extract unique dates from slots, sorted
  const uniqueDates = useMemo(() => {
    const dates = Array.from(new Set(timeSlots.map(s => s.date))).sort();
    return dates;
  }, [timeSlots]);

  const [selectedDate, setSelectedDate] = useState<string>(uniqueDates[0] || new Date().toISOString().split('T')[0]);
  const [selectedCourtId, setSelectedCourtId] = useState<string>('all');
  const [timeOfDayFilter, setTimeOfDayFilter] = useState<'all' | 'morning' | 'afternoon' | 'evening'>('all');

  // Filter slots for current view
  const currentSlots = useMemo(() => {
    return timeSlots.filter(slot => {
      if (slot.date !== selectedDate) return false;
      if (selectedCourtId !== 'all' && slot.courtLocationId !== selectedCourtId) return false;
      
      // Parse hour for morning/afternoon/evening
      const timeStr = slot.startTime; // e.g., "09:15 AM"
      const isPM = timeStr.includes('PM');
      let hour = parseInt(timeStr.split(':')[0], 10);
      if (isPM && hour !== 12) hour += 12;
      if (!isPM && hour === 12) hour = 0;

      if (timeOfDayFilter === 'morning' && hour >= 12) return false;
      if (timeOfDayFilter === 'afternoon' && (hour < 12 || hour >= 17)) return false;
      if (timeOfDayFilter === 'evening' && hour < 17) return false;

      return true;
    });
  }, [timeSlots, selectedDate, selectedCourtId, timeOfDayFilter]);

  // Count open slots per date
  const openCountByDate = useMemo(() => {
    const counts: Record<string, number> = {};
    timeSlots.forEach(slot => {
      if (slot.isAvailable) {
        counts[slot.date] = (counts[slot.date] || 0) + 1;
      }
    });
    return counts;
  }, [timeSlots]);

  const formatDateLabel = (dateStr: string) => {
    const d = new Date(dateStr + 'T00:00:00');
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const monthName = d.toLocaleDateString('en-US', { month: 'short' });
    const dayNum = d.getDate();
    return { dayName, monthName, dayNum, isToday: new Date().toISOString().split('T')[0] === dateStr };
  };

  return (
    <section id="availability" className="py-20 bg-slate-900 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-400/10 border border-purple-400/20 text-purple-400 text-xs font-bold uppercase tracking-wider">
            <CalendarIcon className="w-3.5 h-3.5" />
            Live Coaching Availability
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            View Schedule & Select Your Time Slot
          </h2>
          <p className="text-slate-300 text-base">
            Click any open purple time slot to reserve your private coaching session. Real-time availability updated daily.
          </p>
        </div>

        {/* Date Selector Carousel */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3 px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Select Date:
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Showing next 14 days
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-thin scrollbar-thumb-slate-700">
            {uniqueDates.map((dateStr) => {
              const { dayName, monthName, dayNum, isToday } = formatDateLabel(dateStr);
              const openCount = openCountByDate[dateStr] || 0;
              const isSelected = selectedDate === dateStr;

              return (
                <button
                  key={dateStr}
                  onClick={() => setSelectedDate(dateStr)}
                  className={`flex-shrink-0 min-w-[100px] p-3 rounded-2xl border text-center transition-all cursor-pointer relative ${
                    isSelected
                      ? 'bg-purple-400 text-slate-950 border-purple-400 shadow-lg shadow-purple-500/20 ring-2 ring-purple-400/40 font-bold'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700'
                  }`}
                >
                  {isToday && (
                    <span className={`absolute top-1.5 right-1.5 text-[9px] uppercase px-1.5 py-0.2 rounded font-extrabold ${
                      isSelected ? 'bg-slate-950 text-purple-400' : 'bg-purple-400 text-slate-950'
                    }`}>
                      Today
                    </span>
                  )}

                  <div className={`text-xs uppercase font-semibold ${isSelected ? 'text-slate-950/80' : 'text-slate-400'}`}>
                    {dayName}
                  </div>
                  <div className="text-xl font-black my-0.5">
                    {monthName} {dayNum}
                  </div>

                  <div className="mt-1">
                    {openCount > 0 ? (
                      <span className={`inline-block text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-slate-950/20 text-slate-950' : 'bg-purple-400/10 text-purple-400 border border-purple-400/20'
                      }`}>
                        {openCount} open
                      </span>
                    ) : (
                      <span className={`inline-block text-[10px] font-medium px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-700 text-slate-400'
                      }`}>
                        Full
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Filters Bar: Court & Time of Day */}
        <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 mb-8 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          
          {/* Court Filter */}
          <div className="flex items-center gap-2 flex-1">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
            <label className="text-xs font-semibold text-slate-300 shrink-0">Court Location:</label>
            <select
              value={selectedCourtId}
              onChange={(e) => setSelectedCourtId(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold rounded-xl px-3 py-2 w-full max-w-xs focus:ring-2 focus:ring-purple-400 outline-none cursor-pointer"
            >
              <option value="all">All Court Locations</option>
              {courts.map(c => (
                <option key={c.id} value={c.id}>{c.name} ({c.type})</option>
              ))}
            </select>
          </div>

          {/* Time of Day Pills */}
          <div className="flex items-center gap-1.5 self-start sm:self-auto bg-slate-900 p-1 rounded-xl border border-slate-800">
            <span className="text-[11px] font-bold text-slate-400 px-2">Time:</span>
            {(['all', 'morning', 'afternoon', 'evening'] as const).map((tod) => (
              <button
                key={tod}
                onClick={() => setTimeOfDayFilter(tod)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-lg capitalize transition-all cursor-pointer ${
                  timeOfDayFilter === tod
                    ? 'bg-purple-400 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {tod}
              </button>
            ))}
          </div>

        </div>

        {/* Time Slots Grid */}
        <div>
          {currentSlots.length === 0 ? (
            <div className="text-center py-16 bg-slate-950/50 rounded-2xl border border-slate-800/80 space-y-3">
              <AlertCircle className="w-10 h-10 text-slate-500 mx-auto" />
              <h3 className="text-lg font-bold text-white">No available time slots found for this filter</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Try selecting a different date above or clearing your court location filter to see open coaching slots.
              </p>
              <button
                onClick={() => { setSelectedCourtId('all'); setTimeOfDayFilter('all'); }}
                className="text-xs font-bold text-purple-400 hover:underline pt-2 inline-block cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentSlots.map((slot) => (
                <div
                  key={slot.id}
                  className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                    slot.isAvailable
                      ? 'bg-slate-800/80 hover:bg-slate-800 border-slate-700/80 hover:border-purple-400/60 shadow-md group cursor-pointer'
                      : 'bg-slate-950/60 border-slate-800/60 opacity-60 cursor-not-allowed'
                  }`}
                  onClick={() => {
                    if (slot.isAvailable) onSelectSlot(slot);
                  }}
                >
                  <div>
                    {/* Time & Availability Badge */}
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className={`w-4 h-4 ${slot.isAvailable ? 'text-purple-400' : 'text-slate-500'}`} />
                        <span className="text-base font-extrabold text-white">
                          {slot.startTime} – {slot.endTime}
                        </span>
                      </div>

                      {slot.isAvailable ? (
                        <span className="text-[11px] font-extrabold bg-purple-400/10 text-purple-400 border border-purple-400/30 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Open
                        </span>
                      ) : (
                        <span className="text-[11px] font-semibold bg-slate-800 text-slate-400 px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          Booked
                        </span>
                      )}
                    </div>

                    {/* Court Location */}
                    <div className="flex items-start gap-2 text-xs text-slate-300 font-medium mb-4">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                      <span>{slot.courtLocationName}</span>
                    </div>
                  </div>

                  {/* Action */}
                  <div className="pt-3 border-t border-slate-700/60">
                    {slot.isAvailable ? (
                      <div className="flex items-center justify-between text-xs font-bold text-purple-400 group-hover:text-purple-300">
                        <span>Sign Up For This Slot</span>
                        <span>Select →</span>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500 font-medium">Slot Unavailable</span>
                    )}
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
